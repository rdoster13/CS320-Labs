package edu.ycp.cs320.booksdb;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.Scanner;

import edu.ycp.cs320.sqldemo.DBUtil;

public class InsertNewBookWithNewAuthor {
	public static void main(String[] args) throws Exception {
		// load Derby JDBC driver
		try {
			Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
		} catch (Exception e) {
			System.err.println("Could not load Derby JDBC driver");
			System.err.println(e.getMessage());
			System.exit(1);
		}

		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;

		// connect to the database
		conn = DriverManager.getConnection("jdbc:derby:test.db;create=true");

		@SuppressWarnings("resource")
		Scanner keyboard = new Scanner(System.in);

		try {
			conn.setAutoCommit(true);

			System.out.print("First name of requested author: ");
			String authFirst = keyboard.nextLine();
			
			System.out.print("Last name of requested author: ");
			String authLast = keyboard.nextLine();
			
					
			// a canned query to find auther_ID that matches author first name and last name 
			stmt = conn.prepareStatement(
					"select authors.author_ID "
					+ "  from authors "
					+ "  where authors.firstname = ?"
					+ " 		and authors.lastname = ?"
			);
			
			
			stmt.setString(1, authFirst);
			stmt.setString(2, authLast);
			
			// execute the query
			resultSet = stmt.executeQuery();
			
			// get the precise schema of the tuples returned as the result of the query
			ResultSetMetaData resultSchema = stmt.getMetaData();

			// iterate through the returned tuples, printing each one
			// count # of rows returned
			int rowsReturned = 0;
											
			while (resultSet.next()) {
				for (int i = 1; i <= resultSchema.getColumnCount(); i++) {
					Object obj = resultSet.getObject(i);
					if (i > 1) {
						System.out.print(",");
					}
					System.out.print(obj.toString());
				}
				System.out.println();
					
				// count # of rows returned
				rowsReturned++;
			};			
			// indicate if the query returned nothing
			if (rowsReturned == 0) {
				System.out.println("No rows returned that matched the query");
			};
						
			stmt.close();
			resultSet.close();
			stmt = null;
						
			System.out.print("Would you like to add the new author? Y/N? ");
			String addAuth = keyboard.nextLine();
			
			if (addAuth.contentEquals("Y") || addAuth.contentEquals("y") ) {
				// a query to insert the book using the AuthorID
				stmt = conn.prepareStatement(
						"  insert into authors (authors.lastname, authors.firstname)"
						+ "values (?, ?) "
				);
							
				// substitute the title entered by the user for the placeholder in the query
				stmt.setString(1, authLast);
				stmt.setString(2, authFirst);
				
				stmt.executeUpdate();
				stmt.close();
				stmt = null;
			};
			
			
			System.out.print("Would you like to add a new book? Y/N? ");
			String addBook = keyboard.nextLine();
			
			if (addBook.contentEquals("Y") || addBook.contentEquals("y") ) {
				// prompt user for each parameter to add new book with existing Author
				System.out.print("First name of new book author: ");
				String authorFirst = keyboard.nextLine();
				
				System.out.print("Last name of new book author: ");
				String authorLast = keyboard.nextLine();
				
				System.out.print("Title of new book: ");
				String title = keyboard.nextLine();
				
				System.out.print("ISBN of new book: ");
				String isbn = keyboard.nextLine();
				
				System.out.print("Published Year of new book: ");
				int pubYear = keyboard.nextInt();
				
				// a canned query to find auther_ID that matches author first name and last name 
				stmt = conn.prepareStatement(
						"select authors.author_ID "
						+ "  from authors "
						+ "  where authors.firstname = ?"
						+ " 		and authors.lastname = ?"
				);
				
				// substitute the title entered by the user for the placeholder in the query
				stmt.setString(1, authorFirst);
				stmt.setString(2, authorLast);
				
				resultSet = stmt.executeQuery();
				
				// get the precise schema of the tuples returned as the result of the query
				resultSchema = stmt.getMetaData();
	
				// iterate through the returned tuples, printing each one
				// count # of rows returned
				rowsReturned = 0;
							
				while (resultSet.next()) {
					for (int i = 1; i <= resultSchema.getColumnCount(); i++) {
						Object obj = resultSet.getObject(i);
						if (i > 1) {
							System.out.print(",");
						}
						System.out.print(obj.toString());
					}
					System.out.println();
					
					// count # of rows returned
					rowsReturned++;
				};			
				// indicate if the query returned nothing
				if (rowsReturned == 0) {
					System.out.println("No rows returned that matched the query");
				};
				
				stmt.close();
				resultSet.close();
				stmt = null;
				
				//verifying correct author was entered. 
				System.out.print("Is this the correct Author? " + authorFirst + 
									" " + authorLast + 
									" If yes, please enter the ID listed above: ");
				int authorID = keyboard.nextInt();
				
				// a query to insert the book using the AuthorID
				stmt = conn.prepareStatement(
						"  insert into books (books.author_id, books.title, books.isbn, books.published)"
						+ "values (?, ?, ?, ?) "
				);
					
				// substitute the title entered by the user for the placeholder in the query
				stmt.setInt(1, authorID);
				stmt.setString(2, title);
				stmt.setString(3, isbn);
				stmt.setInt(4, pubYear);
	
				// execute the query
				stmt.executeUpdate();
			} 

			// prompt user for title to search for
			System.out.print("Author's last name to find: ");
			String lastName = keyboard.nextLine();
			// a canned query to find book information (including author name) from title
			stmt = conn.prepareStatement(
					"select authors.lastname, authors.firstname, books.title, books.isbn, books.published "
					+ "  from authors, books "
					+ "  where authors.author_id = books.author_id "
					+ "        and authors.lastname = ?"
			);

			// substitute the title entered by the user for the placeholder in the query
			stmt.setString(1, lastName);

			// execute the query
			resultSet = stmt.executeQuery();

			// get the precise schema of the tuples returned as the result of the query
			resultSchema = stmt.getMetaData();

			// iterate through the returned tuples, printing each one
			// count # of rows returned
			rowsReturned = 0;
			
			while (resultSet.next()) {
				for (int i = 1; i <= resultSchema.getColumnCount(); i++) {
					Object obj = resultSet.getObject(i);
					if (i > 1) {
						System.out.print(",");
					}
					System.out.print(obj.toString());
				}
				System.out.println();
				
				// count # of rows returned
				rowsReturned++;
			}
			
			// indicate if the query returned nothing
			if (rowsReturned == 0) {
				System.out.println("No rows returned that matched the query");
			}

		} finally {
			// close result set, statement, connection
			DBUtil.closeQuietly(resultSet);
			DBUtil.closeQuietly(stmt);
			DBUtil.closeQuietly(conn);
		}
	}
}
